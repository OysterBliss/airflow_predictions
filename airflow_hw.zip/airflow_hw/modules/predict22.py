import os
import json
import pandas as pd
import dill
from sklearn.pipeline import Pipeline
from datetime import datetime

path = os.environ.get('PROJECT_PATH', '..')

def predict():
    latest = sorted(os.listdir(f'{path}/data/models'))[-1]
    with open(f'{path}/data/models/{latest}', 'rb') as file:
        model = dill.load(file)
    dataf = []
    for i in os.listdir(path='/home/airflow/airflow_hw/data/test'):
        with open(f'{path}/data/test/{i}') as ff:
            load = json.load(ff)
        df = pd.DataFrame.from_dict([load])
        y = model.predict(df)
        lst = [load['id'], y[0]]
        dataf.append(lst)
    dfl = pd.DataFrame.from_dict(dataf)
    dfl.columns = ['id', 'price_category']
    dfl.to_csv(f'{path}/data/predictions/pred_{datetime.now().strftime("%Y%m%d%H%M")}.csv')



if __name__ == '__main__':
    predict()
